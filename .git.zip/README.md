<p>npm install</p>
In the .env file replace the <YOUR_METERED_DOMAIN> with your Metered Domain and <YOUR_METERED_SECRET_KEY> with your Metered Secret Key.
